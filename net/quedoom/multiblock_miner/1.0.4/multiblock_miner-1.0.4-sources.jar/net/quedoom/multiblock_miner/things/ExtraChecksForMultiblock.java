package net.quedoom.multiblock_miner.things;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class ExtraChecksForMultiblock {
    public static boolean enchantment(Level level, ItemStack destroyedWith) {
        return true;
    }
}
