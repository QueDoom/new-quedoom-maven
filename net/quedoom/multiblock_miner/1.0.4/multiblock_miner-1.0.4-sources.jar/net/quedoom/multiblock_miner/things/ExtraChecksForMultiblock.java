package net.quedoom.multiblock_miner.things;

import net.minecraft.world.item.ItemStack;

public class ExtraChecksForMultiblock {
    public static boolean enchantment(ItemStack destroyedWith) {
        return true;
    }
}
